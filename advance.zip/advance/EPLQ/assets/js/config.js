// --- FIREBASE CONFIGURATION ---
// TODO: Replace with your actual Firebase project keys
export const firebaseConfig = {
    apiKey: "AIzaSyCL7-tl1MxV9D25KNam-Ov698w5HSucn-w",
    authDomain: "eqpl-525ca.firebaseapp.com",
    projectId: "eqpl-525ca",
    storageBucket: "eqpl-525ca.firebasestorage.app",
    messagingSenderId: "669944091780",
    appId: "1:669944091780:web:3ccb574a2b850da9821ed1",
    measurementId: "G-7P7EPT5SRQ"
  };